-- ============================================================
-- 汽车维修问答数据分析 — 简历数据填充脚本
-- 库名：data_clean_train  表名：train_data
-- 用法：mysql -uroot -p data_clean_train < analysis_queries.sql
--       或逐段在 Navicat / DBeaver / DataGrip 里执行，把结果填进简历的【__】
-- ============================================================

USE data_clean_train;

-- ------------------------------------------------------------
-- Q0 核心指标基线：回答率、平均字数、紧急占比、价格咨询占比
--     填到简历"项目背景"和"指标卡"
-- ------------------------------------------------------------
SELECT
    COUNT(*)                                                    AS 总工单数,
    SUM(is_answered = 1)                                        AS 已回答数,
    ROUND(SUM(is_answered = 1) / COUNT(*) * 100, 2)             AS 整体回答率_pct,
    ROUND(AVG(NULLIF(problem_wordcount, 0)), 0)                 AS 平均提问字数,
    ROUND(AVG(tech_speech_count), 1)                            AS 平均技师发言数,
    ROUND(AVG(owner_speech_count), 1)                           AS 平均车主发言数,
    ROUND(SUM(urgency_level = 'Urgent') / COUNT(*) * 100, 2)    AS 紧急工单占比_pct,
    ROUND(SUM(contains_price = 1) / COUNT(*) * 100, 2)          AS 价格咨询占比_pct
FROM train_data;


-- ------------------------------------------------------------
-- Q1 品牌集中度：TOP10 品牌工单量 + 各自占比
--     结论模板：TOP10 品牌贡献 __% 的工单
-- ------------------------------------------------------------
SELECT
    brand,
    COUNT(*) AS 工单数,
    ROUND(COUNT(*) / (SELECT COUNT(*) FROM train_data
                      WHERE brand IS NOT NULL AND brand <> '') * 100, 2) AS 占比_pct
FROM train_data
WHERE brand IS NOT NULL AND brand <> ''
GROUP BY brand
ORDER BY 工单数 DESC
LIMIT 10;

-- Q1b TOP10 累计集中度（MySQL 8.0+，低版本把子查询单独跑）
SELECT
    ROUND(SUM(cnt) / (SELECT COUNT(*) FROM train_data
                      WHERE brand IS NOT NULL AND brand <> '') * 100, 2) AS TOP10累计占比_pct
FROM (
    SELECT brand, COUNT(*) AS cnt
    FROM train_data
    WHERE brand IS NOT NULL AND brand <> ''
    GROUP BY brand
    ORDER BY cnt DESC
    LIMIT 10
) t;


-- ------------------------------------------------------------
-- Q2 提问字数分桶：6 段分布
--     结论模板：__% 的提问在 40 字以内
-- ------------------------------------------------------------
SELECT
    CASE
        WHEN problem_wordcount BETWEEN 1  AND 20  THEN '01_0-20字'
        WHEN problem_wordcount BETWEEN 21 AND 40  THEN '02_21-40字'
        WHEN problem_wordcount BETWEEN 41 AND 60  THEN '03_41-60字'
        WHEN problem_wordcount BETWEEN 61 AND 80  THEN '04_61-80字'
        WHEN problem_wordcount BETWEEN 81 AND 100 THEN '05_81-100字'
        WHEN problem_wordcount > 100              THEN '06_100字以上'
    END AS 字数区间,
    COUNT(*) AS 工单数,
    ROUND(COUNT(*) / (SELECT COUNT(*) FROM train_data WHERE problem_wordcount > 0) * 100, 2) AS 占比_pct
FROM train_data
WHERE problem_wordcount > 0
GROUP BY 字数区间
ORDER BY 字数区间;


-- ------------------------------------------------------------
-- Q3 交叉分析：紧急程度 × 回答率  ★核心结论
--     结论模板：Urgent 回答率 __%，低于整体 __ 个百分点
-- ------------------------------------------------------------
SELECT
    CASE urgency_level
        WHEN 'Urgent'  THEN '1_紧急'
        WHEN 'Warning' THEN '2_较紧急'
        WHEN 'Normal'  THEN '3_一般'
        WHEN 'Mild'    THEN '4_轻微'
        ELSE '9_未知'
    END                                        AS 紧急程度,
    COUNT(*)                                   AS 工单数,
    ROUND(COUNT(*) / SUM(COUNT(*)) OVER () * 100, 2) AS 占比_pct,
    SUM(is_answered = 1)                       AS 已回答数,
    ROUND(SUM(is_answered = 1) / COUNT(*) * 100, 2) AS 回答率_pct
FROM train_data
WHERE urgency_level IN ('Urgent', 'Warning', 'Normal', 'Mild')
GROUP BY urgency_level
ORDER BY 紧急程度;


-- ------------------------------------------------------------
-- Q4 交叉分析：问题类型 × 价格咨询占比 × 回答率
--     结论模板：__ 类问题价格咨询占比最高（__%），是付费转化入口
-- ------------------------------------------------------------
SELECT
    problem_type,
    COUNT(*)                                          AS 工单数,
    ROUND(COUNT(*) / (SELECT COUNT(*) FROM train_data
                      WHERE problem_type IS NOT NULL AND problem_type <> '') * 100, 2) AS 占比_pct,
    ROUND(SUM(contains_price = 1) / COUNT(*) * 100, 2) AS 价格咨询占比_pct,
    ROUND(SUM(is_answered = 1) / COUNT(*) * 100, 2)    AS 回答率_pct,
    ROUND(AVG(NULLIF(problem_wordcount, 0)), 0)        AS 平均提问字数
FROM train_data
WHERE problem_type IS NOT NULL AND problem_type <> ''
GROUP BY problem_type
ORDER BY 工单数 DESC;


-- ------------------------------------------------------------
-- Q5 交叉分析：字数区间 × 回答率
--     结论模板：字数越少回答率越 __，描述质量与响应效率相关
-- ------------------------------------------------------------
SELECT
    CASE
        WHEN problem_wordcount BETWEEN 1  AND 20  THEN '01_0-20字'
        WHEN problem_wordcount BETWEEN 21 AND 40  THEN '02_21-40字'
        WHEN problem_wordcount BETWEEN 41 AND 60  THEN '03_41-60字'
        WHEN problem_wordcount BETWEEN 61 AND 80  THEN '04_61-80字'
        WHEN problem_wordcount BETWEEN 81 AND 100 THEN '05_81-100字'
        WHEN problem_wordcount > 100              THEN '06_100字以上'
    END AS 字数区间,
    COUNT(*)                                        AS 工单数,
    ROUND(SUM(is_answered = 1) / COUNT(*) * 100, 2) AS 回答率_pct
FROM train_data
WHERE problem_wordcount > 0
GROUP BY 字数区间
ORDER BY 字数区间;


-- ------------------------------------------------------------
-- Q6 对比分析：品牌级别 × 诉求颗粒度
--     结论模板：豪华品牌平均提问字数 __，高于/低于其他级别
-- ------------------------------------------------------------
SELECT
    brand_level,
    COUNT(*)                                         AS 工单数,
    ROUND(AVG(NULLIF(problem_wordcount, 0)), 0)      AS 平均提问字数,
    ROUND(AVG(tech_speech_count), 1)                 AS 平均技师发言数,
    ROUND(SUM(contains_price = 1) / COUNT(*) * 100, 2) AS 价格咨询占比_pct,
    ROUND(SUM(is_answered = 1) / COUNT(*) * 100, 2)  AS 回答率_pct
FROM train_data
WHERE brand_level IS NOT NULL AND brand_level <> ''
GROUP BY brand_level
ORDER BY 工单数 DESC;


-- ------------------------------------------------------------
-- Q7 数据质量体检：空值率 + 重复 QID
--     写进"数据清洗"那一条，体现有质量意识
-- ------------------------------------------------------------
SELECT
    COUNT(*)                                                 AS 总记录数,
    SUM(problem IS NULL OR problem = '')                     AS problem空值,
    SUM(brand IS NULL OR brand = '')                         AS brand空值,
    SUM(problem_type IS NULL OR problem_type = '')           AS 问题类型空值,
    SUM(brand_level IS NULL OR brand_level = '')             AS 品牌级别空值,
    SUM(urgency_level IS NULL OR urgency_level = '')         AS 紧急程度空值,
    SUM(problem_wordcount IS NULL OR problem_wordcount = 0)  AS 字数缺失或零,
    SUM(is_answered IS NULL)                                 AS 回答状态缺失
FROM train_data;

SELECT COUNT(*) AS 重复QID组数
FROM (SELECT qid FROM train_data GROUP BY qid HAVING COUNT(*) > 1) t;


-- ------------------------------------------------------------
-- Q8 结构分析：问题类型排序（对应看板柱状图）
-- ------------------------------------------------------------
SELECT
    problem_type,
    COUNT(*) AS 工单数,
    ROUND(COUNT(*) / (SELECT COUNT(*) FROM train_data
                      WHERE problem_type IS NOT NULL AND problem_type <> '') * 100, 2) AS 占比_pct
FROM train_data
WHERE problem_type IS NOT NULL AND problem_type <> ''
GROUP BY problem_type
ORDER BY 工单数 DESC;


-- ------------------------------------------------------------
-- 附加：如果后续想补"响应效率"指标，先在表里加时间字段
-- ALTER TABLE train_data ADD COLUMN first_reply_minutes INT NULL COMMENT '首次响应分钟数';
-- 然后才能算：SELECT AVG(first_reply_minutes) FROM train_data;
-- 这一点可以写进面试的"下一步优化"
-- ------------------------------------------------------------
