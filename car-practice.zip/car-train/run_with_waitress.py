import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from waitress import serve
from app import create_app

app = create_app()
print("Starting server on http://0.0.0.0:8080...")
serve(app, host='0.0.0.0', port=8080)