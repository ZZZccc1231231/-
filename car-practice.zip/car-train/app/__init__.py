import os

from flask import Flask, redirect
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS  # 新增：导入CORS

db = SQLAlchemy()

# 导入接口蓝图
from app.api.job_analysis_api import job_analysis_bp
from app.api.car_repair_api import car_repair_bp

def create_app():  # 用法
    """
    创建Flask应用
    """
    # static_folder 指向项目根目录下的 dashboard，前端页面可通过 /dashboard/index.html 访问
    # 这样页面里的相对接口地址 /api/car_repair 就是同源请求，不会跨域失败
    dashboard_dir = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'dashboard'
    )
    app = Flask(__name__, static_folder=dashboard_dir, static_url_path='/dashboard')

    from app.config import config
    app_config = config

    app.config['SQLALCHEMY_DATABASE_URI'] = app_config.SQLALCHEMY_DATABASE_URI
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = app_config.SQLALCHEMY_TRACK_MODIFICATIONS

    db.init_app(app)

    # 📌 全局开启跨域，允许所有来源
    CORS(app, supports_credentials=True)

    app.register_blueprint(job_analysis_bp)
    app.register_blueprint(car_repair_bp)

    # 根路径直接跳转到看板页面
    @app.route('/')
    def index():
        return redirect('/dashboard/index.html')

    return app