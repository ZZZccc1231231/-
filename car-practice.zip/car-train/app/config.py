import os
class Config:
    # 数据库配置
    DB_HOST = os.environ.get('DB_HOST', 'localhost')
    DB_PORT = os.environ.get('DB_PORT', '3306')
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '123456')
    DB_NAME = os.environ.get('DB_NAME', 'data_cleaning_train_set')

    SQLALCHEMY_DATABASE_URI = f'mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # 导入配置
    IMPORT_BATCH_SIZE = int(os.environ.get('IMPORT_BATCH_SIZE', '100'))

    # 日志配置
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
config=Config()