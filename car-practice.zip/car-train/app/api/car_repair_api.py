from flask import Blueprint, jsonify
from app.services.car_repair_service import CarRepairService

# 注册蓝图
car_repair_bp = Blueprint('car_repair', __name__, url_prefix='/api/car_repair')


@car_repair_bp.route('/statistics', methods=['GET'])
def get_statistics():
    """获取统计概览数据"""
    data = CarRepairService.get_statistics()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/problem_type/distribution', methods=['GET'])
def get_problem_type_distribution():
    """获取问题类型分布数据"""
    data = CarRepairService.get_problem_type_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/brand_level/distribution', methods=['GET'])
def get_brand_level_distribution():
    """获取品牌级别分布数据"""
    data = CarRepairService.get_brand_level_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/word_count/distribution', methods=['GET'])
def get_word_count_distribution():
    """获取问题字数分布数据"""
    data = CarRepairService.get_word_count_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/urgency_level/distribution', methods=['GET'])
def get_urgency_level_distribution():
    """获取紧急程度分布数据"""
    data = CarRepairService.get_urgency_level_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/price_consult/distribution', methods=['GET'])
def get_price_consult_distribution():
    """获取价格咨询分布数据"""
    data = CarRepairService.get_price_consult_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/answer_status/distribution', methods=['GET'])
def get_answer_status_distribution():
    """获取回答状态分布数据"""
    data = CarRepairService.get_answer_status_distribution()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })


@car_repair_bp.route('/brand_rank', methods=['GET'])
def get_brand_rank():
    """获取品牌问题排行数据"""
    data = CarRepairService.get_brand_rank()
    return jsonify({
        'code': 200,
        'msg': 'success',
        'data': data
    })