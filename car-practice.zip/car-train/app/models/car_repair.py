from app import db

class CarRepair(db.Model):
    """汽车维修数据模型 - 匹配 train_data 表"""
    __tablename__ = 'train_data'

    id = db.Column(db.Integer, primary_key=True)
    qid = db.Column(db.String(100))
    brand = db.Column(db.String(100))
    collection = db.Column(db.String(255))
    problem = db.Column(db.Text)
    conversation = db.Column(db.Text)
    report = db.Column(db.Text)
    problem_clean = db.Column(db.Text)
    conversation_clean = db.Column(db.Text)
    report_clean = db.Column(db.Text)
    problem_wordcount = db.Column(db.Integer)
    tech_speech_count = db.Column(db.Integer)
    owner_speech_count = db.Column(db.Integer)
    problem_type = db.Column(db.String(100))
    brand_level = db.Column(db.String(50))
    urgency_level = db.Column(db.String(50))
    contains_price = db.Column(db.Integer)
    is_answered = db.Column(db.Integer)