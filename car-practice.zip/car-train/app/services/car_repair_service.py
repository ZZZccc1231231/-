# -*- coding: utf-8 -*-
"""
汽车维修数据分析Service：生成ECharts图表数据
"""
from app.models.car_repair import CarRepair, db
from sqlalchemy import func


class CarRepairService:
    @staticmethod
    def get_statistics():
        """
        获取统计概览数据
        返回：总问题数、已回答数、平均问题字数、技师发言数、车主发言数、回答率
        """
        try:
            # 总问题数
            total_count = db.session.query(
                func.count(CarRepair.id).label('count')
            ).first()
            total = total_count.count if total_count else 0

            # 已回答数
            answered_count = db.session.query(
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.is_answered == 1
            ).first()
            answered = answered_count.count if answered_count else 0

            # 平均问题字数
            avg_wordcount = db.session.query(
                func.avg(CarRepair.problem_wordcount).label('avg')
            ).filter(
                CarRepair.problem_wordcount != None,
                CarRepair.problem_wordcount > 0
            ).first()
            avg_word = int(avg_wordcount.avg) if avg_wordcount and avg_wordcount.avg else 0

            # 技师发言数总和
            tech_speech_sum = db.session.query(
                func.sum(CarRepair.tech_speech_count).label('sum')
            ).filter(
                CarRepair.tech_speech_count != None
            ).first()
            tech_speech = tech_speech_sum.sum if tech_speech_sum else 0

            # 车主发言数总和
            owner_speech_sum = db.session.query(
                func.sum(CarRepair.owner_speech_count).label('sum')
            ).filter(
                CarRepair.owner_speech_count != None
            ).first()
            owner_speech = owner_speech_sum.sum if owner_speech_sum else 0

            # 回答率（保留2位小数，未全部回答时不超过99.99%）
            if total > 0:
                rate = (answered / total) * 100
                answer_rate = "{:.2f}%".format(rate)
                # 兜底：数据量很大时四舍五入仍可能显示100.00%
                if answered < total and answer_rate == "100.00%":
                    answer_rate = "99.99%"
            else:
                answer_rate = "0.00%"

            return {
                'totalQuestionCount': total,
                'answeredCount': answered,
                'avgWordCount': avg_word,
                'techSpeechCount': tech_speech,
                'ownerSpeechCount': owner_speech,
                'answerRate': answer_rate
            }

        except Exception as e:
            print("统计数据获取异常：", str(e))
            return {
                'totalQuestionCount': 0,
                'answeredCount': 0,
                'avgWordCount': 0,
                'techSpeechCount': 0,
                'ownerSpeechCount': 0,
                'answerRate': '0.0%'
            }

    @staticmethod
    def get_problem_type_distribution():
        """
        按问题类型统计数量（柱状图数据）
        """
        try:
            result = db.session.query(
                CarRepair.problem_type,
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.problem_type != None,
                CarRepair.problem_type != ""
            ).group_by(
                CarRepair.problem_type
            ).order_by(
                func.count(CarRepair.id).desc()
            ).all()

            xAxis = []
            series_data = []
            colors = ['#00f5ff', '#36cfc9', '#52c41a', '#faad14', '#ff7875', '#722ed1']
            
            for i in range(len(result)):
                row = result[i]
                xAxis.append(row.problem_type)
                series_data.append({
                    'value': row.count,
                    'itemStyle': {
                        'color': colors[i % len(colors)]
                    }
                })

            return {
                'xAxis': xAxis,
                'series_data': series_data
            }

        except Exception as e:
            print("问题类型分布统计异常：", str(e))
            return {
                'xAxis': [],
                'series_data': []
            }

    @staticmethod
    def get_brand_level_distribution():
        """
        按品牌级别统计数量（饼图数据）
        """
        try:
            result = db.session.query(
                CarRepair.brand_level,
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.brand_level != None,
                CarRepair.brand_level != ""
            ).group_by(
                CarRepair.brand_level
            ).order_by(
                func.count(CarRepair.id).desc()
            ).all()

            series_data = []
            colors = ['#00f5ff', '#36cfc9', '#ff7875', '#ffa940', '#722ed1']
            color_index = 0

            for row in result:
                series_data.append({
                    'value': row.count,
                    'name': row.brand_level,
                    'itemStyle': {
                        'color': colors[color_index % len(colors)]
                    }
                })
                color_index += 1

            return {
                'series_data': series_data
            }

        except Exception as e:
            print("品牌级别分布统计异常：", str(e))
            return {
                'series_data': []
            }

    @staticmethod
    def get_word_count_distribution():
        """
        按问题字数区间统计数量（折线图数据）
        """
        try:
            # 定义字数区间
            ranges = [
                (0, 20, '0-20字'),
                (21, 40, '21-40字'),
                (41, 60, '41-60字'),
                (61, 80, '61-80字'),
                (81, 100, '81-100字'),
                (101, 9999, '100字以上')
            ]

            xAxis = []
            series_data = []

            for min_val, max_val, label in ranges:
                count = db.session.query(
                    func.count(CarRepair.id).label('count')
                ).filter(
                    CarRepair.problem_wordcount != None,
                    CarRepair.problem_wordcount >= min_val,
                    CarRepair.problem_wordcount <= max_val
                ).first()
                xAxis.append(label)
                series_data.append(count.count if count else 0)

            return {
                'xAxis': xAxis,
                'series_data': series_data
            }

        except Exception as e:
            print("问题字数分布统计异常：", str(e))
            return {
                'xAxis': [],
                'series_data': []
            }

    @staticmethod
    def get_urgency_level_distribution():
        """
        按紧急程度统计数量（柱状图数据）
        """
        try:
            # 定义紧急程度映射（数据库存储的是英文值）
            urgency_mapping = [
                {'db_value': 'Urgent', 'display': '紧急'},
                {'db_value': 'Warning', 'display': '较紧急'},
                {'db_value': 'Normal', 'display': '一般'},
                {'db_value': 'Mild', 'display': '轻微'}
            ]
            
            xAxis = []
            series_data = []
            colors = ['#ff4d4f', '#ff7875', '#faad14', '#52c41a']

            for i in range(len(urgency_mapping)):
                mapping = urgency_mapping[i]
                count = db.session.query(
                    func.count(CarRepair.id).label('count')
                ).filter(
                    CarRepair.urgency_level == mapping['db_value']
                ).first()
                xAxis.append(mapping['display'])
                series_data.append({
                    'value': count.count if count else 0,
                    'itemStyle': {
                        'color': colors[i % len(colors)]
                    }
                })

            return {
                'xAxis': xAxis,
                'series_data': series_data
            }

        except Exception as e:
            print("紧急程度分布统计异常：", str(e))
            return {
                'xAxis': [],
                'series_data': []
            }

    @staticmethod
    def get_price_consult_distribution():
        """
        按是否包含价格咨询统计（饼图数据）
        """
        try:
            result = db.session.query(
                CarRepair.contains_price,
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.contains_price != None,
                CarRepair.contains_price.in_([0, 1])
            ).group_by(
                CarRepair.contains_price
            ).all()

            series_data = []
            for row in result:
                name = '包含价格咨询' if row.contains_price == 1 else '不包含价格咨询'
                color = '#52c41a' if row.contains_price == 1 else '#722ed1'
                series_data.append({
                    'value': row.count,
                    'name': name,
                    'itemStyle': {
                        'color': color
                    }
                })

            return {
                'series_data': series_data
            }

        except Exception as e:
            print("价格咨询分布统计异常：", str(e))
            return {
                'series_data': []
            }

    @staticmethod
    def get_answer_status_distribution():
        """
        按回答状态统计（饼图数据）
        """
        try:
            result = db.session.query(
                CarRepair.is_answered,
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.is_answered != None,
                CarRepair.is_answered.in_([0, 1])
            ).group_by(
                CarRepair.is_answered
            ).all()

            series_data = []
            for row in result:
                name = '已回答' if row.is_answered == 1 else '未回答'
                color = '#1890ff' if row.is_answered == 1 else '#ff4d4f'
                series_data.append({
                    'value': row.count,
                    'name': name,
                    'itemStyle': {
                        'color': color
                    }
                })

            return {
                'series_data': series_data
            }

        except Exception as e:
            print("回答状态分布统计异常：", str(e))
            return {
                'series_data': []
            }

    @staticmethod
    def get_brand_rank():
        """
        按品牌统计问题数量排行（柱状图数据，取TOP10）
        """
        try:
            result = db.session.query(
                CarRepair.brand,
                func.count(CarRepair.id).label('count')
            ).filter(
                CarRepair.brand != None,
                CarRepair.brand != ""
            ).group_by(
                CarRepair.brand
            ).order_by(
                func.count(CarRepair.id).desc()
            ).limit(10).all()

            xAxis = []
            series_data = []

            for row in result:
                xAxis.append(row.brand)
                series_data.append(row.count)

            return {
                'xAxis': xAxis,
                'series_data': series_data
            }

        except Exception as e:
            print("品牌问题排行统计异常：", str(e))
            return {
                'xAxis': [],
                'series_data': []
            }